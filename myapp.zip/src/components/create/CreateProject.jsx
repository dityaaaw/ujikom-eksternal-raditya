import React, { useState } from 'react';
import { projectAPI } from '../user/projectAPI';
import Swal from 'sweetalert2';
import './CreateProject.css';

const CreateProjectPage = () => {
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    const [imageUrl, setImageUrl] = useState('');
    const [budget, setBudget] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!name || !description || !imageUrl || !budget) {
            alert("Mohon di isi yang masih kosong.");
            return;
        }

        try {
            await projectAPI.create({
                name,
                imageUrl,
                description,
                budget
            });

            // Menampilkan Sweet Alert setelah berhasil membuat proyek
            Swal.fire({
                icon: 'success',
                title: 'Success!',
                text: 'Project has been successfully created.'
            }).then(() => {
                window.location.href = "http://localhost:3000/projects/admin";
            });
        } catch (error) {
            // Tangani kesalahan jika ada
            console.error(error);
        }
    };

    const handleDescriptionChange = (e) => {
        if (e.target.value.length <= 500) {
            setDescription(e.target.value);
        }
    };

    return (
        <div>
            <div className='create'>
                <h1>Create New Project</h1>
                <form onSubmit={handleSubmit}>
                    <div>
                        <label>Name:</label>
                        <input type="text" value={name} placeholder='Masukan Nama Anda' onChange={(e) => setName(e.target.value)} />
                    </div>
                    <div>
                        <label>Description:</label>
                        <textarea
                            value={description}
                            onChange={handleDescriptionChange}
                            maxLength={500}
                            placeholder='Maximal Kata 500'
                        />
                    </div>
                    <div>
                        <label>Image URL:</label>
                        <input type="text" value={imageUrl} placeholder='Masukan Link Anda' onChange={(e) => setImageUrl(e.target.value)} />
                    </div>
                    <div>
                        <label>Budget:</label>
                        <input
                            type="number"
                            value={budget}
                            onChange={(e) => setBudget(e.target.value)}
                            min="0"
                            placeholder='Masukan Budget Untuk Makanan Anda'
                        />
                    </div>
                    <button type="submit">Create Project</button>
                </form>
            </div>
        </div>
    );
};

export default CreateProjectPage;
