import React from "react";
import { Link } from "react-router-dom";
import Swal from "sweetalert2";

const FormatDescription = (description) => {
  return description.substring(0, 50) + "...";
};

const ProjectCard = (props) => {
  const { project, onDelete } = props;

  const buy = () => {
    Swal.fire({
      title: "Are you sure?",
      text: "You are about to buy this Food?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#d33",
      cancelButtonColor: "#3085d6",
      confirmButtonText: "Yes, Buy it!",
    }).then((result) => {
      if (result.isConfirmed) {
        Swal.fire({
          title: "Thank You!",
          text: "Your purchase has been successful.",
          icon: "success",
        });
      }
    });
  };

  return (
    <div className="card">
      <img src={project.imageUrl} alt={project.name} className="projectImg" />
      <section className="section-dark">
        <Link to={"/projects/" + project.id}>
          <h5 className="strong">
            <strong>{project.name}</strong>
          </h5>
          <p>{FormatDescription(project.description)}</p>
          <p>harga: {project.budget.toLocaleString()}</p>
        </Link>
        <button onClick={buy}>Buy</button>
      </section>
    </div>
  );
};

export default ProjectCard;
