
let users = []; // Simulasi data pengguna

const createUser = (req, res) => {
  const userData = req.body;
  users.push(userData);
  res.status(201).json({ message: 'User created successfully!' });
};

module.exports = { createUser };
