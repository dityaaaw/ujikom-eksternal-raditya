import React, { useState } from 'react';
import { userAPI } from './userAPI';
import { Link } from 'react-router-dom';
import './SignUp.css';

const SignUp = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');

    const handleSignUp = async () => {
        try {
            const existingUser = await userAPI.findUserByUsername(username);
            if (existingUser) {
                alert('Username already exists!');
                return;
            }

            const newUser = {
                id: Date.now(),
                username: username,
                password: password
            };

            await userAPI.createUser(newUser);
            alert('User created successfully! You can now login.');
            setUsername('');
            setPassword('');
        } catch (error) {
            console.error('Error signing up:', error.message);
        }
    };

    return (
        <div>
            <h2>Sign Up</h2>
            <div className='sign'>
                <div>
                    <label>Username:</label>
                    <input type="text" value={username} placeholder='Enter your username' onChange={(e) => setUsername(e.target.value)} />
                </div>
                <div>
                    <label>Password:</label>
                    <input type="password" value={password} placeholder='Enter your password' onChange={(e) => setPassword(e.target.value)} />
                </div>
                <button onClick={handleSignUp}>Sign Up</button>
                <Link to="/login" className="btn">Back To Login</Link>
            </div>
        </div>
    );
};

export default SignUp;
