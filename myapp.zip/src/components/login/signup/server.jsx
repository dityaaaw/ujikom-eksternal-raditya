

const express = require('express');
const bodyParser = require('body-parser');
const { createUser } = require('./userController');

const app = express();
const PORT = process.env.PORT || 3001;

app.use(bodyParser.json());

app.post('/signup', createUser);

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
