const baseURL = "http://localhost:4001";
const url = `${baseURL}/users`;

const translateStatusToErrorMessage = (status) => {
    switch (status) {
        case 401:
            return "Please login again.";
        case 403:
            return "You don't have permission to view the project.";
        default:
            return "There was an error. Please try again.";
    }
};

const checkStatus = (response) => {
    if (response.ok) {
        return response;
    } else {
        const httpErrorInfo = {            status: response.status,
            statusText: response.statusText,
            url: response.url,
        };
        console.log(`Server HTTP error: ${JSON.stringify(httpErrorInfo)}`);

        let errorMsg = translateStatusToErrorMessage(httpErrorInfo.status);
        throw new Error(errorMsg);
    }
};

const createUser = async (userData) => {
    try {
        const response = await fetch(url);
        const responseData = await checkStatus(response);
        const existingIds = responseData.map((item) => parseInt(item.id));
        const maxId = Math.max(...existingIds);
        const newId = maxId + 1;
        userData.id = String(newId);

        const createResponse = await fetch(url, {
            method: "POST",
            body: JSON.stringify(userData),
            headers: {
                "Content-Type": "application/json",
            },
        });
        await checkStatus(createResponse);
    } catch (error) {
        console.log("Client error:", error);
        throw new Error("There was an error creating the project. Please try again.");
    }
};

const login = async (username, password) => {
    try {
        const response = await fetch(`${url}?username=${username}&password=${password}`);
        await checkStatus(response);
        const user = await response.json();
        return user;
    } catch (error) {
        console.error('Error logging in:', error.message);
        throw error;
    }
};

const findUserByUsername = async (username) => {
    try {
        const response = await fetch(`${url}?username=${username}`);
        const users = await response.json();
        return users.find(user => user.username === username);
    } catch (error) {
        console.error('Error finding user:', error.message);
        throw error;
    }
};

export const userAPI = {
    createUser: createUser,
    login: login,
    findUserByUsername: findUserByUsername,
};
