import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import './App.css';
import { IoHomeSharp } from "react-icons/io5";
import { MdMenuBook } from "react-icons/md";
import { IoIosCreate } from "react-icons/io";
import Swal from 'sweetalert2';

const Navbar = () => {
  // Fungsi untuk logout
  const handleLogout = () => {
    // Tampilkan pesan sukses menggunakan SweetAlert2
    const Toast = Swal.mixin({
      toast: true,
      position: "top-end",
      showConfirmButton: false,
      timer: 3000,
      timerProgressBar: true,
      didOpen: (toast) => {
        toast.onmouseenter = Swal.stopTimer;
        toast.onmouseleave = Swal.resumeTimer;
      }
    });
    Toast.fire({
      icon: "success",
      title: "Logout successfully"
    });
    // Lakukan navigasi ke halaman logout
    // navigate("/logout");
  };

  return (
    <header className="sticky">
      {/* Logo */}
      <span className="logo">
        <img src="pdg.png" alt="logo" width={'70'} height={"70"} className='NavImg'/>
      </span>
      <div>
        {/* NavLink untuk halaman Home */}
        <NavLink to="/Home" className='container2 button rounded'>
          <span><IoHomeSharp /></span>
          <span> </span>
          Home
        </NavLink>
        {/* NavLink untuk halaman Projects (MENU) */}
        <NavLink to="/projects" className='container3 button rounded'>
          <span><MdMenuBook /></span>
          <span> </span>
          MENU
        </NavLink>
        {/* NavLink untuk halaman Create (hanya ditampilkan di halaman admin) */}
        <ConditionalCreateNavLink />
        {/* NavLink untuk logout */}
        <NavLink to="/" className='container4 button rounded' onClick={handleLogout}>
          <span><MdMenuBook /></span>
          <span> </span>
          Logout
        </NavLink>
      </div>
    </header>
  );
};

// Komponen untuk menampilkan NavLink Create (hanya ditampilkan di halaman admin)
const ConditionalCreateNavLink = () => {
  const location = useLocation();

  // Cek lokasi saat ini, jika di halaman admin, tampilkan NavLink Create
  if (location.pathname === '/projects/admin') {
    return (
      <NavLink to="/Create" className='container5 button rounded'>
        <span><IoIosCreate /></span>
        <span> </span>
        Create
      </NavLink>
    );
  }

  return null; // Sembunyikan NavLink Create untuk rute lainnya
};

// Komponen untuk menampilkan Navbar (hanya ditampilkan di halaman selain login dan signup)
const ConditionalNavbar = () => {
  const location = useLocation();

  // Cek lokasi saat ini, jika di halaman login atau signup, sembunyikan Navbar
  if (location.pathname === '/' ) {
    return null;
  }

  return <Navbar />;
};

export default ConditionalNavbar;
