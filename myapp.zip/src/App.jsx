import React from 'react';
import './App.css';
import ProjectsPage from './components/user/ProjectsPage';
import ProjectPage from './components/user/ProjectPage';
import HomePage from './home/HomePage';
import CreateProjectPage from './components/create/CreateProject';
import Login from './components/login/signup/Login';
import Admin from "./components/admin/ProjectsPage"
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Navbar from './NavBar';



function App() {
  return (
      <div className="container">
        <Router>
          <Navbar/>
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/projects" element={<ProjectsPage />} />
          <Route path='/projects/:id' element={<ProjectPage />} />
          <Route path='/projects/admin' element={<Admin />} />
          <Route path='/Create' element={<CreateProjectPage />} />
          <Route path='/Home' element={<HomePage />} />
        </Routes>
        </Router>
      </div>
  );
}

export default App;
